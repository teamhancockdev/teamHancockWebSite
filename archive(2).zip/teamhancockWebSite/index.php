<?php
session_start();

//Get values passed from form in home.html file

$email=$_POST['email'];
$password=$_POST['password'];


$db = mysqli_connect("db702298437.db.1and1.com" , "dbo702298437" , "Evertonfc_1878" , "db702298437");

//to prevent sql injection

$email = stripcslashes($email);
$password = stripcslashes($password);

// connect to database



 $sql = "SELECT * FROM users WHERE email = '$email' and password = '$password'";
      
            
      $result = mysqli_query($db, $sql);
     
      
      $count = mysqli_num_rows($result);
      
      // If result matched $email and $password, table row must be 1 row
		
      if($count == 1) {
       
         header("location: home.html");
      }else {
         header("location: signup.php");
      }
   ?>
