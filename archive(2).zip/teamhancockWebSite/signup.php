<?php 
session_start();
$db = mysqli_connect("db702298437.db.1and1.com" , "dbo702298437" , "Evertonfc_1878" , "db702298437");

if (isset($_POST['register_btn'])) {
session_start();
  $username = ($_POST['username']);
  $email = ($_POST['email']);
  $password = ($_POST['password']);
  $confirm = ($_POST['confirm']);
  
  if ($password == $confirm) {
   //create user
    $password = ($password); //hash password before storing for security
    $sql = "INSERT INTO users(username, email, password) VALUES ('$username', '$email' , '$password')";
    mysqli_query($db, $sql);
    $_SESSION['username'] = "You are now logged in";
    $_SESSION['username'] = $username;
    header ("location: home.html"); //redirect to homepage
  }else {
    //failed
    $_SESSION['message'] = "The two passwords do not match";
  }
  
}
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <title>teamHancock</title>
  <meta charset="utf-8">
  <meta name="description" content="Sign up to teamHancocks website to learn more about our website design products and also android application development">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" text="text/css" href="signupstyle.css">
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script type="text/javascript" src="fade.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<!--NAVBAR START-->
<!--NAVBAR START-->
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand"><img src="logo.png"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
       <li><a href="home.html"><span class="glyphicon glyphicon-home"></span>
Home</a></li>
        <li><a href="story.html"><span class="glyphicon glyphicon-book"></span>
Our Story</a></li>
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="portfolio.html"><span class="glyphicon glyphicon-console"></span>
  Development Solutions
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="android.html"><span class="glyphicon glyphicon-phone"></span>
Android Development</a></li>
          <li><a href="websitedev.html"><span class="glyphicon glyphicon-thumbs-up"></span>
Website Development</a></li>
          </ul>
      </li>
              <li><a href="social.html"><span class="glyphicon glyphicon-thumbs-up"></span>
Social Media</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="signup.html"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
       <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-save  "></span><b>Login</b> <span class="caret"></span></a>
			<ul id="login-dp" class="dropdown-menu">
				<li>
					 <div class="row">
							<div class="col-md-12">
								Login via
								<div class="social-buttons">
									<a href="#" class="btn btn-fb"><i class="fa fa-facebook"></i> Facebook</a>
									<a href="#" class="btn btn-tw"><i class="fa fa-twitter"></i> Twitter</a>
								</div>
                                or
								 <form class="form" role="form" method="post" action="login" accept-charset="UTF-8" id="login-nav">
										<div class="form-group">
											 <label class="sr-only" for="exampleInputEmail2">Email address</label>
											 <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Email address" required>
										</div>
										<div class="form-group">
											 <label class="sr-only" for="exampleInputPassword2">Password</label>
											 <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Password" required>
                                             <div class="help-block text-right"><a href="">Forgot Your Password ?</a></div>
										</div>
										<div class="form-group">
											 <button type="submit" class="btn btn-primary btn-block">Sign in</button>
										</div>
										<div class="checkbox">
											 <label>
											 <input type="checkbox"> keep me logged-in
											 </label>
										</div>
								 </form>
							</div>
							<div class="bottom text-center">
								New here? <a href="signup.php"><b>Sign Up</b></a>
							</div>
					 </div>
           
				</li>
    </ul>
     <li><a href="contactus.html"><span class="glyphicon glyphicon-envelope"></span> Contact Us</a></li>
    </div>
  </div>
</nav> <!--NAVBAR END--> 
<br/>
<br/>
<div class="container-fluid">
<div class="header"> <!--IMAGE HEADER-->
<img src="smallheader.png" class="center-block img-responsive" alt="header">
</div>
</div>

<!--BUTTONS-->

<div class="container-fluid">
<div class="btn-group btn-group-justified">
  <a button type="button" class="btn btn-primary" data-toggle="modal" data-target="#AndroidModal">Android</a>
  <a button type="button" class="btn btn-primary" data-toggle="modal" data-target="#WebModal">Websites</a>
</div>

<div id="AndroidModal" class="modal fade" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-title"><img src="androidheader.png" class="center-block img-responsive" alt="boxing-life">
</div>
</div>
<div class="modal-body">
<h3>We currently have a range of applications on the GooglePlay Store! </br>
We manage the analytics and updates for these applications. <br>
We will be including facebook and twitter integration in our next release!</h3>
<img src="boxinglife.png" class="img-responsive" alt="boxing-life">
<a href="http://play.google.com/store/apps/details?id=com.teamhancock.boxinginfo"><img src="googleplay.png" class="center-block img-rounded" alt="googleplaylogo" width="300" height="125">
</div>
<div class="modal-footer">
<button type="button" class="btn btn-Primary" data-dismiss="modal">Close</button></div>
</div>
</div>
</div>

<div id="WebModal" class="modal fade" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<div class="modal-title"><img src="responsive.png" class="center-block img-responsive" alt="boxing-life">
</div>
</div>
<div class="modal-body">
<h3>Currently we are producing quality responsive website for sole traders and small to medium businesses. </br>
Our websites are tested against a range of devices to ensure that your website gives your customers the best experience possible.</h3>
<img src="responsiveweb.png" class="img-responsive" alt="ResponsiveSite">
<h3> Check out one of our customers website at <a href="http://www.salvagebarbers.co.uk">www.salvagebarbers.co.uk</a></h3>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-Primary" data-dismiss="modal">Close</button></div>
</div>
</div>
</div>


<div class="greeting">
<script src="greeting.js"></script>
</div>


</head>
<body>


<div class="parallax"></div><!--parallax-->

<div class="panel panel-primary">
      <div class="panel-heading">
      Sign Up</div>
      <div class="panel-body">
      
      Sign up to teamHancock Development studios to receive regular updates and offers about our upcoming promotions.<br>
      All new sign ups will recieve a 5% discount on their first order across website or application designs.
      <br>
      <br>
      
	<div class="container">
			<div class="row main">
				<div class="main-login main-center">
						<form action="signup.php" method="post" action="">
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Your Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="name" id="name"  placeholder="Enter your Name"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="email" id="email"  placeholder="Enter your Email"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Username</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						</div>
</br>
</br>
						<div class="form-group ">
							<input type="submit" name="register_btn" value="Register" class="btn btn-primary btn-lg btn-block login-button">
						</div>
						
					</form>
				</div>
			</div>
		</div>
       </div>
    </div>
    
    
    <div class="parallax"></div><!--parallax-->
    
    
<div class="panel panel-primary">
      <div class="panel-heading">Contact Us</div>
      <div class="panel-body"> 
      <a href="#"><img src="fbooklogo.png" class="img-rounded" width="75" height="75" alt="facebooklogo">
      <a href="https://twitter.com/teamhancock_Dev?s=09" title="twitter"><img src="twitterlogo.png" class="img-rounded" width="75" height="75" alt="twitterlogo"></a>
      <a href="https://www.instagram.com/team_hancock_dev/"><img src="instagramlogo.png" class="img-rounded" width="75" height="75" alt="instagramlogo">
      </div>
    </div>
    
</body>
</html>